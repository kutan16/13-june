import {Component} from '@angular/core';

@Component({
    selector:'<my-component></my-component>',
    templateUrl:'./app.employeecomponent.html',
    
})
export class AppEmployeeComponent{
    empId:number=1001;
    isDisabled:string='true';
    
}
import {Component} from '@angular/core';

@Component({
    selector:'<my-component></my-component>',
    templateUrl:'./app.employeecomponent.html',
    
})
export class AppEmployeeComponent{
    status:boolean=true;
    onClick():void{
        console.log('WELCOME to EVENT');
        console.log("Hello World");
    }
    show():void{
        this.status=!this.status;
    }
    
}
import { Component } from '@angular/core';

@Component({
  selector: 'new-app',
  template:'<h1><i> from {{address}}</i></h1>',
  styles : ['div{color:aqua}']
})

export class MyComponent
{
	address = "Pune";
}
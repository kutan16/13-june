import { Component } from '@angular/core';
import { MyComponent } from './MyComponent';
@Component({
  selector: 'my-app',
  templateUrl:'./app.component.html',
  
})
export class AppComponent 
{ 
name = 'Bharati'; 
}

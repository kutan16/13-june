export interface IEmployee{
    empId:Number,
    empName:String,
    empSalary:number;
    empDepartment:string;

}
var Student = (function () {
    function Student(name, id, address) {
        this.sName = name;
        this.sId = id;
        this.sAddress = address;
        Student.cnt++;
    }
    Student.prototype.getSId = function () {
        return this.sId;
    };
    Student.prototype.setSId = function (id) {
        this.sId = id;
    };
    Student.cnt = 0;
    return Student;
})();
var stu = new Student("Amrita", 101, "Pune");
console.log("total objects = " + Student.cnt);
console.log("id = " + stu.getSId());
console.log(stu.sName + " " + stu.sId + " " + stu.sAddress);

interface Person
{
	name : string;
	address : string;
	contact : number;
}

let person : Person[] = [{

	name : "Riya",
	address : "Mumbai",
	contact : 232323}, {
	name : "Raj",
	address : "Chennai",
	contact : 32323
	}
	
]
for( let i=0;i<person.length;i++ ){
console.log(person[i].name + " " +person[i].address +" "+person[i].contact);
}
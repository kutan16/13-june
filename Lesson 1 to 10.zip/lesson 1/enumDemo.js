var big = 10;
var medium = 5;
var small = 2;
var coffeesize;
(function (coffeesize) {
    coffeesize[coffeesize["big"] = 0] = "big";
    coffeesize[coffeesize["medium"] = 1] = "medium";
    coffeesize[coffeesize["small"] = 2] = "small";
})(coffeesize || (coffeesize = {}));
;
var coffee = coffeesize.small;
console.log(coffee);
var str = "Hello World";
console.log(str.length);

var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
var Employee = (function () {
    function Employee(name) {
        this.name = name;
    }
    Employee.prototype.getName = function () {
        return this.name;
    };
    return Employee;
})();
var Manager = (function (_super) {
    __extends(Manager, _super);
    function Manager(name, designation) {
        _super.call(this, name);
        this.designation = designation;
    }
    Manager.prototype.getDesignation = function () {
        return this.designation;
    };
    return Manager;
})(Employee);
var mgr = new Manager("Uma", "Senior Manager");
console.log(mgr.getName() + "  " + mgr.getDesignation());

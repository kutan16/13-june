const big=10;
const medium=5;
const small=2;

enum coffeesize {big,medium,small};

let coffee = coffeesize.small;
console.log(coffee);

let str : string = "Hello World";

console.log( (<string>str).length);
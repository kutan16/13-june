var msg = "Ram";
console.log("Hello ${msg}! how are you");

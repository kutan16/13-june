var data : any;
data = 123;
let arr:number[] = [10,20,30];
console.log("arr = "+arr);
let arrany : any[] = [10,"Bharati","98500000"];
console.log("arrany = "+arrany);
for(var num=1;num<5;num++)
{
		console.log("num = "+num);
}
console.log("data = "+data);
console.log("num = "+num);
class Student
{
	sName : string;
	sId : number;
	sAddress : string;
	static cnt : number = 0;
	constructor(name : string , id : number , address:string)
	{
		this.sName = name;
		this.sId  = id;
		this.sAddress = address;
		Student.cnt++;
	}
	getSId() : number {
		return this.sId;
	}
	setSId(id:number) : void 
	{
		this.sId = id;
	}
}

let stu = new Student("Amrita",101,"Pune");
console.log("total objects = "+Student.cnt);
console.log("id = "+stu.getSId());
console.log(stu.sName + " "+ stu.sId +" " +stu.sAddress);
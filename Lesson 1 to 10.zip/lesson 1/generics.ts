function display<T>(msg : T) : void {

	console.log(msg);
}

display("Hello");
display(12);
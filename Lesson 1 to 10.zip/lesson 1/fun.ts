/*let display = function()
{
	console.log("Hello World");
}

display();
*/

let arDisplay =()=>console.log("Hello World");
arDisplay();

let msgDisplay = (msg)=>console.log(msg);
msgDisplay("Hello Everyone");
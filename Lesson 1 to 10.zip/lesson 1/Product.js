var IProduct = (function () {
    function IProduct() {
    }
    return IProduct;
})();
exports.IProduct = IProduct;
exports.company = "capgemini";

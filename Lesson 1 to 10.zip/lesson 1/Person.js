var person = [{
        name: "Riya",
        address: "Mumbai",
        contact: 232323 }, {
        name: "Raj",
        address: "Chennai",
        contact: 32323
    }
];
for (var i = 0; i < person.length; i++) {
    console.log(person[i].name + " " + person[i].address + " " + person[i].contact);
}

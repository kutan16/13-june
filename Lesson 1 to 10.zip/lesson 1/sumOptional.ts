function sum(num1:number,num2:number=10,num3?:number):number
{
	return num1+num2+num3;
}

let data = sum(20);
console.log("data = "+data);

data = sum(20,12);
console.log("data = "+data);

data = sum(20,10,3);
console.log("data = "+data);

function sum() {
    var num = [];
    for (var _i = 0; _i < arguments.length; _i++) {
        num[_i - 0] = arguments[_i];
    }
    var sm = 0;
    for (var i = 0; i < num.length; i++) {
        sm = sm + num[i];
    }
    return sm;
}
var result = sum(9, 7);
console.log("result = " + result);
result = sum(1, 2, 3);
console.log("result = " + result);

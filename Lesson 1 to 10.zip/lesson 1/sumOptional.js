function sum(num1, num2, num3) {
    if (num2 === void 0) { num2 = 10; }
    return num1 + num2 + num3;
}
var data = sum(20);
console.log("data = " + data);
data = sum(20, 12);
console.log("data = " + data);
data = sum(20, 10, 3);
console.log("data = " + data);

function sum(...num : number[]):number
{
	let sm = 0;
	for(let i=0;i<num.length;i++)
	{
		sm = sm + num[i];
	}
	return sm;
}

let result = sum(9,7);
console.log("result = "+result);
result = sum(1,2,3);
console.log("result = "+result);

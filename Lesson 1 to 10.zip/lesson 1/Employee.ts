class Employee
{
	name : string;
	
	constructor(name : string){
		this.name = name;
	}
	getName() : string
	{
		return this.name;
	}
}
class Manager extends Employee
{
	designation : string;
	
	constructor(name : string , designation : string)
	{
		super(name);
		this.designation = designation;
	}
	getDesignation() : string
	{
		return this.designation;
	}
}
let mgr = new Manager("Uma", "Senior Manager");
console.log(mgr.getName() + "  " +mgr.getDesignation());

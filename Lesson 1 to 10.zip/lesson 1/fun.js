/*let display = function()
{
    console.log("Hello World");
}

display();
*/
var arDisplay = function () { return console.log("Hello World"); };
arDisplay();
var msgDisplay = function (msg) { return console.log(msg); };
msgDisplay("Hello Everyone");

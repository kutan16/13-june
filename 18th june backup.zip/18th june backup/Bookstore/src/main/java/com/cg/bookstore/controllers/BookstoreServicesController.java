package com.cg.bookstore.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.cg.bookstore.beans.Customer;
import com.cg.bookstore.exceptions.CustomerDetailsNotFoundException;
import com.cg.bookstore.services.BookstoreServices;

@Controller
public class BookstoreServicesController {
	
	
	 @Autowired
	 private BookstoreServices bookstoreServices;
	
	 @RequestMapping(value={"/acceptCustomerDetails"},method=RequestMethod.POST,consumes=MediaType.APPLICATION_FORM_URLENCODED_VALUE)
	 public ResponseEntity<String> acceptCustomerDetails(@ModelAttribute Customer customer) throws CustomerDetailsNotFoundException{
		customer=bookstoreServices.acceptCustomerDetails(customer);
		return new ResponseEntity<>("Customer details successfully added,  email Id is   "+customer.getEmailId(),HttpStatus.OK);
	}
	
	@RequestMapping(value={"/getCustomerDetails/{emailId}"},method=RequestMethod.GET,produces=MediaType.APPLICATION_JSON_VALUE,
			headers="Accept=application/json")
	public ResponseEntity<Customer> getCustomerDetailsPathParam(@PathVariable(name="emailId") String emailId) throws CustomerDetailsNotFoundException{
		return new ResponseEntity<Customer>(bookstoreServices.getCustomerDetails(emailId),HttpStatus.OK);
	}
	 
	@RequestMapping(value={"/getAllCustomerDetails"},method=RequestMethod.GET,produces=MediaType.APPLICATION_JSON_VALUE,
			headers="Accept=application/json")
	public ResponseEntity<List<Customer>> getCustomerDetailsPathParam() throws CustomerDetailsNotFoundException {
		return new ResponseEntity<List<Customer>>(bookstoreServices.getAllCustomerDetails(),HttpStatus.OK);
	}

	@RequestMapping(value={"/removeCustomerDetails/{emailId}"},method=RequestMethod.DELETE)//,consumes=MediaType.APPLICATION_FORM_URLENCODED_VALUE)
	public ResponseEntity<String> removeCustomerDetails(@RequestParam /*name="emailId")*/ String emailId) throws CustomerDetailsNotFoundException{
		bookstoreServices.deleteCustomer(emailId);
		return new ResponseEntity<>("Customer details successfully removed",HttpStatus.OK);
	} 
}

package com.cg.bookstore.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cg.bookstore.beans.Customer;
import com.cg.bookstore.dao.CustomerDAO;
import com.cg.bookstore.exceptions.CustomerDetailsNotFoundException;
@Component("bookstoreServices")
public class BookstoreServicesImpl implements BookstoreServices{

	@Autowired
	CustomerDAO customerDao;
	
	@Override
	public Customer acceptCustomerDetails(Customer customer) {
		// TODO Auto-generated method stub
		return customerDao.save(customer);
	}

	@Override
	public Customer getCustomerDetails(String emailId) throws CustomerDetailsNotFoundException {
		// TODO Auto-generated method stub
		return customerDao.findById(emailId).orElseThrow(()-> new 
				CustomerDetailsNotFoundException("Customer Details Not Found"));
	}

	@Override
	public List<Customer> getAllCustomerDetails() {
		// TODO Auto-generated method stub
		return customerDao.findAll();
	}

	@Override
	public boolean deleteCustomer(String emailId) throws CustomerDetailsNotFoundException {
//		Customer customer = customerDao.findById(emailId).orElseThrow(()-> new 
//				CustomerDetailsNotFoundException("Customer Details Not Found"));
		customerDao.deleteById(emailId);
//		customer=customerDao.save(customer);
		return false;
	}

}

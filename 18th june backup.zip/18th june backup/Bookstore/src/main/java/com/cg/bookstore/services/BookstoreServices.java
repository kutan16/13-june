package com.cg.bookstore.services;

import java.util.List;

import com.cg.bookstore.beans.Customer;
import com.cg.bookstore.exceptions.CustomerDetailsNotFoundException;

public interface BookstoreServices {

		Customer acceptCustomerDetails(Customer customer);
		Customer getCustomerDetails(String emailId)throws CustomerDetailsNotFoundException;
		List<Customer> getAllCustomerDetails();
		boolean deleteCustomer(String emailId)throws CustomerDetailsNotFoundException;
}

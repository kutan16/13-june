package com.cg.bookstore.beans;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Users {

	@Id
	private String userEmailId;
	private String userFullName;
	private String userPassword;
	public Users() {
		super();
	}
	public Users(String userEmailId, String userFullName, String userPassword) {
		super();
		this.userEmailId = userEmailId;
		this.userFullName = userFullName;
		this.userPassword = userPassword;
	}
	public String getUserEmailId() {
		return userEmailId;
	}
	public void setUserEmailId(String userEmailId) {
		this.userEmailId = userEmailId;
	}
	public String getUserFullName() {
		return userFullName;
	}
	public void setUserFullName(String userFullName) {
		this.userFullName = userFullName;
	}
	public String getUserPassword() {
		return userPassword;
	}
	public void setUserPassword(String userPassword) {
		this.userPassword = userPassword;
	}
	@Override
	public String toString() {
		return "User [userEmailId=" + userEmailId + ", userFullName=" + userFullName + ", userPassword=" + userPassword
				+ "]";
	}
		
}

package com.cg.bookstore.aspect;

import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.servlet.ModelAndView;

import com.cg.bookstore.exceptions.CustomerDetailsNotFoundException;

@ControllerAdvice
public class BookstoreExceptionAspect {

	@ExceptionHandler(CustomerDetailsNotFoundException.class)
	public ModelAndView handleAssociateDetailsNotFoundException(Exception e) {
		return new ModelAndView("findCustomerDetailsPage","errorMessage ",e.getMessage());
	}
}

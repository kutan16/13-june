package com.cg.bookstore.beans;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;

@Entity
public class Reviews {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int reviewId;
	private String headline;
	private String comment;
	@Min(1)
	@Max(5)
	private int rating;
	@OneToOne
	private Book book;
	@OneToOne
	private Customer customer;
	public Reviews() {
		super();
	}
	public Reviews(int reviewId, String headline, String comment, @Min(1) @Max(5) int rating, Book book,
			Customer customer) {
		super();
		this.reviewId = reviewId;
		this.headline = headline;
		this.comment = comment;
		this.rating = rating;
		this.book = book;
		this.customer = customer;
	}
	public int getReviewId() {
		return reviewId;
	}
	public void setReviewId(int reviewId) {
		this.reviewId = reviewId;
	}
	public String getHeadline() {
		return headline;
	}
	public void setHeadline(String headline) {
		this.headline = headline;
	}
	public String getComment() {
		return comment;
	}
	public void setComment(String comment) {
		this.comment = comment;
	}
	public int getRating() {
		return rating;
	}
	public void setRating(int rating) {
		this.rating = rating;
	}
	public Book getBook() {
		return book;
	}
	public void setBook(Book book) {
		this.book = book;
	}
	public Customer getCustomer() {
		return customer;
	}
	public void setCustomer(Customer customer) {
		this.customer = customer;
	}
	@Override
	public String toString() {
		return "Review [reviewId=" + reviewId + ", headline=" + headline + ", comment=" + comment + ", rating=" + rating
				+ ", book=" + book + ", customer=" + customer + "]";
	}
}

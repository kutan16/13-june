package com.cg.bookstore.beans;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
@Entity
public class Orders {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int orderId;
	@ManyToOne
	private Customer customer;
	@OneToMany
	private List<Book> book;
	private String orderedStatus;
	private String paymentMethod;
	
	public Orders() {
		super();
	}
	public Orders(int orderId, Customer customer, List<Book> book, String orderedStatus, String paymentMethod) {
		super();
		this.orderId = orderId;
		this.customer = customer;
		this.book = book;
		this.orderedStatus = orderedStatus;
		this.paymentMethod = paymentMethod;
	}
	public int getOrderId() {
		return orderId;
	}
	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}
	public Customer getCustomer() {
		return customer;
	}
	public void setCustomer(Customer customer) {
		this.customer = customer;
	}
	public List<Book> getBook() {
		return book;
	}
	public void setBook(List<Book> book) {
		this.book = book;
	}
	public String getOrderedStatus() {
		return orderedStatus;
	}
	public void setOrderedStatus(String orderedStatus) {
		this.orderedStatus = orderedStatus;
	}
	public String getPaymentMethod() {
		return paymentMethod;
	}
	public void setPaymentMethod(String paymentMethod) {
		this.paymentMethod = paymentMethod;
	}
	@Override
	public String toString() {
		return "Order [orderId=" + orderId + ", customer=" + customer + ", book=" + book + ", orderedStatus="
				+ orderedStatus + ", paymentMethod=" + paymentMethod + "]";
	}
	
}

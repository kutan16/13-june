import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'my-widths-responsive',
  templateUrl: './widths-responsive.component.html',
  styleUrls: ['./widths-responsive.component.css']
})
export class WidthsResponsiveComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

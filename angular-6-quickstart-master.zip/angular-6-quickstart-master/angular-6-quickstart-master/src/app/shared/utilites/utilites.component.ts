import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'my-utilites',
  templateUrl: './utilites.component.html',
  styleUrls: ['./utilites.component.css']
})
export class UtilitesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

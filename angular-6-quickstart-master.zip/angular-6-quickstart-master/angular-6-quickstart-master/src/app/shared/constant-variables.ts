export class ConstantVariables {
    country = 'country';
    capital = 'capital';
    ascending = 'asc';
    descending = 'desc'
}

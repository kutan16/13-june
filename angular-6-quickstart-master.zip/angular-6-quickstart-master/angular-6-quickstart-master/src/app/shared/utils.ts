export class SharedUtils {
    
    isStringNullOrEmpty(value): boolean {
        let returnFlag = (value) ? false : true;
        return returnFlag
    }
}

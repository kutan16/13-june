import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'my-spacing-responsive',
  templateUrl: './spacing-responsive.component.html',
  styleUrls: ['./spacing-responsive.component.css']
})
export class SpacingResponsiveComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
